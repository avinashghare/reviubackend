<?php echo $this->load->view('fronthand/includes/header'); ?>

<?php echo $this->load->view('fronthand/includes/'.$page); ?>

<?php echo $this->load->view('fronthand/includes/footer'); ?>